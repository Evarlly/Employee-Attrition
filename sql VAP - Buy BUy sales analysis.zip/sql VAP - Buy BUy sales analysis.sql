SELECT *
FROM sales_data;

--add profit column to the table--

ALTER TABLE sales_data
ADD COLUMN profit INT;

--Total profit made by buybuy from 1Q11 to 4Q22--

SELECT SUM(profit) AS "Total Profit"
FROM sales_data;

SELECT date_part('quarter',sales_date), sales_year AS "Year", SUM(profit) AS "Total_Profit"
FROM sales_data
GROUP BY 1,2
ORDER BY 1,2;

--Total profit made by Buybuy in the Q2 of every year from 2011 to 2016--

SELECT date_part('quarter',sales_date), sales_year AS "Year", SUM(profit) AS "Total_Profit"
FROM sales_data	
	WHERE date_part('quarter',sales_date) = '2'
GROUP BY 1,2
ORDER BY 1,2;


--Annual Profit made by buy from 2011 to 2016--

SELECT sales_year, SUM(profit)
FROM sales_data
GROUP BY 1
ORDER BY 1;

--Create a chart to Visualize the Data in 1b--

SELECT date_part('quarter',sales_date), sales_year AS "Year", SUM(profit) AS "Total_Profit"
FROM sales_data	
	WHERE date_part('quarter',sales_date) = '2'
GROUP BY 1,2
ORDER BY 1,2;

--2. Region Profit Analysis--
--a. Countries where Buybuy made the most profit of all time and the least profit--

SELECT cus_country, SUM(profit) AS "Profit"
FROM sales_data
GROUP BY 1
ORDER BY 1 DESC;

--b.Top 10 most profitable country for Buybuy sales operations from 2011 to 2016--

SELECT cus_country, SUM(profit) AS "Profit"
FROM sales_data
GROUP BY 1
ORDER BY 2 DESC
LIMIT 10;

--All time top ten least profitable countries for Buybuy--

SELECT cus_country, SUM(profit) AS "Profit"
FROM sales_data
GROUP BY 1
ORDER BY 2 ASC
LIMIT 10;


--3 PRODUCT REVENUE ANALYSIS--

/*a. Product categories sold by Buybuy, from least amount to most amount of all time 
revenue generated*/


SELECT prod_category, SUM(revenue)
FROM sales_data
GROUP BY 1
ORDER BY 2 ASC;

--Top 2 product category offered by buybuy with an all time highest number of units sold--

SELECT prod_category, MAX(ord_quantity)
FROM sales_data
GROUP BY 1
ORDER BY 2 DESC
LIMIT 2;

--Top 10 highest-grossing products sold by buybuy based on all time profits--

SELECT product, SUM(profit)
FROM sales_data
GROUP BY 1
ORDER BY 2 DESC
LIMIT 10;


